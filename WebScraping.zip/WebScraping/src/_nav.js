export default {
  items: [{
      name: 'Dashboard',
      url: '/dashboard',
      icon: 'fa fa-tachometer',
      badge: {
        variant: 'primary',
        text: 'NEW'
      }
    },
    {
      name: 'Configuration',
      url: '',
      icon: 'fa fa-puzzle-piece',
      children: [{
        name: 'Document Setup',
        url: '/documentsetup',
        icon: 'fa fa-file-text'
      }]
    },
    {
      name: 'Operation',
      url: '',
      icon: 'fa fa-clock-o',
      children: [{
          name: 'Preprocessed Image',
          url: '/preprocessedimage',
          icon: 'fa fa-image'
        },
        {
          name: 'Classification',
          url: '/classification',
          icon: 'fa fa-star'
        },
        {
          name: 'MetaData Extraction',
          url: '/metadataextraction',
          icon: 'fa fa-cloud-upload'
        },
        {
          name: 'MetaData(3JS)',
          url: '/metadataextractionthree',
          icon: 'fa fa-cloud-upload'
        }
      ]
    }
  ]
}