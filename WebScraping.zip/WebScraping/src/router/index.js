import Vue from 'vue';
import Router from 'vue-router';
import TheLayout from '../components/shared/TheLayout.vue'

Vue.use(Router);
const router = new Router({
  routes: [{
    path: '/',
    component: TheLayout,
    name: 'layout',
    childrens: [{
        path: 'dashboard',
        name: 'dashboard',
        component: () =>
          import('@/components/Dashboard.vue')
      },
      {
        path: 'documentsetup',
        name: 'documentSetup',
        component: () =>
          import('@/components/configuration/DocumentSetup.vue')
      }, {
        path: '/preprocessedimage',
        name: 'preprocessedImage',
        component: () =>
          import('@/components/operation/PreprocessedImage.vue')
      }, {
        path: '/classification',
        name: 'classification',
        component: () =>
          import('@/components/operation/Classification.vue')
      }, {
        path: '/metadataextraction',
        name: 'metaDataExtraction',
        component: () =>
          import('@/components/operation/MetaDataExtraction.vue')
      }, {
        path: '/metadataextractionthree',
        name: 'metaDataExtractionThree',
        component: () =>
          import('@/components/operation/MetaDataExtractionThree.vue')
      }
    ]
  }]
})

export default router;