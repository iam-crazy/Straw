import TheHeader from './components/TheHeader'
import TheFooter from './components/TheFooter'
import TheBreadcrumb from './components/TheBreadcrumb'

const FramworkModule = {
    TheHeader,
    TheFooter,
    TheBreadcrumb
}
export default FramworkModule;
export {
    TheHeader,
    TheFooter,
    TheBreadcrumb
}