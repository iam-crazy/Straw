<template lang="html">

  <section class="the-menu">
    <h1>the-menu Component</h1>
  </section>

</template>

<script lang="js">
  export default  {
    name: 'the-menu',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style scoped lang="scss">
  .the-menu {

  }
</style>
