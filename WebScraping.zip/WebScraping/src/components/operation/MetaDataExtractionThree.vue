<template lang="html">

  <section class="meta-data-extraction-three">
    <h1>meta-data-extraction-three Component</h1>
  </section>

</template>

<script lang="js">
  export default  {
    name: 'meta-data-extraction-three',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style>
</style>
