<template lang="html">

  <section class="preprocessed-image">
    <h1>preprocessed-image Component</h1>
  </section>

</template>

<script lang="js">
  export default  {
    name: 'preprocessed-image',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style>
</style>
