<template lang="html">
<div class="app">
    <TheHeader fixed>
      <SidebarToggler class="d-lg-none" display="md" mobile />
      <b-link  class="navbar-brand" to="#">
        <img class="navbar-brand-full" src="../../assets/img/logo.png" width="89" height="25" alt="CoreUI Logo">
        <img class="navbar-brand-minimized" src="../../assets/img/brand/sygnet.svg" width="30" height="30" alt="CoreUI Logo">
      </b-link>
      <SidebarToggler class="d-md-down-none" display="lg" />
      <b-navbar-nav class="d-md-down-none">
        <b-nav-item class="px-3">Web Scraping</b-nav-item>
      </b-navbar-nav>
      <b-navbar-nav class="ml-auto">
        <b-nav-item class="d-md-down-none">
          <i class="icon-bell"></i>
          <b-badge pill variant="danger">5</b-badge>
        </b-nav-item>
        <!-- <b-nav-item class="d-md-down-none">
          <i class="icon-list"></i>
        </b-nav-item> -->
        <!-- <b-nav-item class="d-md-down-none">
          <i class="icon-location-pin"></i>
        </b-nav-item> -->
        <DefaultHeaderDropdownAccnt/>
      </b-navbar-nav>
     <!--  <AsideToggler class="d-none d-lg-block" />
     <AsideToggler class="d-lg-none" mobile />-->
    </TheHeader>
    <div class="app-body">
      <AppSidebar fixed>
        <SidebarHeader/>
        <SidebarForm/>
        <SidebarNav :navItems="nav"></SidebarNav>
        <SidebarFooter/>
             </AppSidebar>
      <main class="main">
        <Breadcrumb :list="list"/>
        <div class="container-fluid">
          <router-view></router-view>
        </div>
      </main>
      <AppAside fixed>
        <!--aside-->
        <!-- <DefaultAside/> -->
      </AppAside>
    </div>
    <TheFooter>
      <!--footer-->
      <div>
        <a href="#">Black Straw</a>
        <span class="ml-1">&copy; 2018 creativeLabs.</span>
      </div>
      <div class="ml-auto">
        <span class="mr-1">Powered by</span>
        <a href="#">AI</a>
      </div>
    </TheFooter>
  </div>
</template>

<script lang="js">
 import nav from '@/_nav'
import {
  // Header as TheHeader,
  SidebarToggler,
  Sidebar as AppSidebar,
  SidebarFooter,
  SidebarForm,
  SidebarHeader,
  SidebarMinimizer,
  SidebarNav,
  Aside as AppAside,
  AsideToggler,
  //Footer as TheFooter,
  //Breadcrumb
} from '@coreui/vue'
// import DefaultAside from '../containers/DefaultAside'
// import DefaultHeaderDropdownAccnt from '../containers/DefaultHeaderDropdownAccnt'
 import {TheHeader, TheFooter, TheBreadcrumb as Breadcrumb} from '../../frameworks'

export default {
  name: 'the-layout',
  components: {
    AsideToggler,
    TheHeader,
    AppSidebar,
    AppAside,
    TheFooter,
    Breadcrumb,
    // DefaultAside,
    // DefaultHeaderDropdownAccnt,
    SidebarForm,
    SidebarFooter,
    SidebarToggler,
    SidebarHeader,
    SidebarNav,
    SidebarMinimizer
  },
  data() {
    return {
      nav: nav.items
    }
  },
  computed: {
    name() {
      return this.$route.name
    },
    list() {
      return this.$route.matched.filter(route => route.name || route.meta.label)
    }
  }
}
</script>

<style scoped lang="scss">
.app-header {
  background-color: #3a4149;
  border-bottom: 1px solid #23282c;
}
.navbar-nav .nav-link {
  color: #c8ced3;
}
.navbar-nav .nav-link:hover,
.navbar-nav .nav-link:focus {
  color: #e4e7ea;
}
.sidebar-nav {
  position: relative;
  -ms-flex: 1;
  flex: 1;
  overflow-x: hidden;
  overflow-y: auto;
  -ms-overflow-style: -ms-autohiding-scrollbar;
}
.sidebar {
}
</style>
